﻿namespace ProjekAkhir
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gunaShadowPanel1 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaTransfarantPictureBox1 = new Guna.UI.WinForms.GunaTransfarantPictureBox();
            this.gunaLabelTglPemasukan = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabelTransPemasukan = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabelJmlPemasukan = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel2 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaTransfarantPictureBox2 = new Guna.UI.WinForms.GunaTransfarantPictureBox();
            this.gunaLabelTglPengeluaran = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabeTransPengeluaran = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabelJmlPengeluaran = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel3 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelPemasukanMax = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel4 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelPemasukanMin = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel5 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelLastPemasukan = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel10 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel6 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabel13 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel14 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel7 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelPengeluaranMax = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel8 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelPengeluaranMin = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel9 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelLastPengeluaran = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel12 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaTransfarantPictureBox1)).BeginInit();
            this.gunaShadowPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaTransfarantPictureBox2)).BeginInit();
            this.gunaShadowPanel3.SuspendLayout();
            this.gunaShadowPanel4.SuspendLayout();
            this.gunaShadowPanel5.SuspendLayout();
            this.gunaShadowPanel6.SuspendLayout();
            this.gunaShadowPanel7.SuspendLayout();
            this.gunaShadowPanel8.SuspendLayout();
            this.gunaShadowPanel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaShadowPanel1
            // 
            this.gunaShadowPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel1.BaseColor = System.Drawing.Color.White;
            this.gunaShadowPanel1.Controls.Add(this.gunaTransfarantPictureBox1);
            this.gunaShadowPanel1.Controls.Add(this.gunaLabelTglPemasukan);
            this.gunaShadowPanel1.Controls.Add(this.gunaLabelTransPemasukan);
            this.gunaShadowPanel1.Controls.Add(this.gunaLabel2);
            this.gunaShadowPanel1.Controls.Add(this.gunaLabelJmlPemasukan);
            this.gunaShadowPanel1.Controls.Add(this.gunaLabel1);
            this.gunaShadowPanel1.Location = new System.Drawing.Point(70, 120);
            this.gunaShadowPanel1.Name = "gunaShadowPanel1";
            this.gunaShadowPanel1.Radius = 10;
            this.gunaShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel1.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel1.Size = new System.Drawing.Size(439, 278);
            this.gunaShadowPanel1.TabIndex = 0;
            // 
            // gunaTransfarantPictureBox1
            // 
            this.gunaTransfarantPictureBox1.BaseColor = System.Drawing.Color.Black;
            this.gunaTransfarantPictureBox1.Image = global::ProjekAkhir.Properties.Resources.transaction_50px1f_2;
            this.gunaTransfarantPictureBox1.Location = new System.Drawing.Point(291, 83);
            this.gunaTransfarantPictureBox1.Name = "gunaTransfarantPictureBox1";
            this.gunaTransfarantPictureBox1.Size = new System.Drawing.Size(96, 96);
            this.gunaTransfarantPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaTransfarantPictureBox1.TabIndex = 5;
            this.gunaTransfarantPictureBox1.TabStop = false;
            // 
            // gunaLabelTglPemasukan
            // 
            this.gunaLabelTglPemasukan.AutoSize = true;
            this.gunaLabelTglPemasukan.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTglPemasukan.Location = new System.Drawing.Point(159, 228);
            this.gunaLabelTglPemasukan.Name = "gunaLabelTglPemasukan";
            this.gunaLabelTglPemasukan.Size = new System.Drawing.Size(164, 21);
            this.gunaLabelTglPemasukan.TabIndex = 4;
            this.gunaLabelTglPemasukan.Text = "TglTerakhirPemasukan";
            // 
            // gunaLabelTransPemasukan
            // 
            this.gunaLabelTransPemasukan.AutoSize = true;
            this.gunaLabelTransPemasukan.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTransPemasukan.Location = new System.Drawing.Point(38, 183);
            this.gunaLabelTransPemasukan.Name = "gunaLabelTransPemasukan";
            this.gunaLabelTransPemasukan.Size = new System.Drawing.Size(97, 21);
            this.gunaLabelTransPemasukan.TabIndex = 3;
            this.gunaLabelTransPemasukan.Text = "JmlTransaksi";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(38, 142);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(74, 21);
            this.gunaLabel2.TabIndex = 2;
            this.gunaLabel2.Text = "Transaksi";
            // 
            // gunaLabelJmlPemasukan
            // 
            this.gunaLabelJmlPemasukan.AutoSize = true;
            this.gunaLabelJmlPemasukan.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelJmlPemasukan.Location = new System.Drawing.Point(38, 83);
            this.gunaLabelJmlPemasukan.Name = "gunaLabelJmlPemasukan";
            this.gunaLabelJmlPemasukan.Size = new System.Drawing.Size(113, 21);
            this.gunaLabelJmlPemasukan.TabIndex = 1;
            this.gunaLabelJmlPemasukan.Text = "JmlPemasukan";
            this.gunaLabelJmlPemasukan.Click += new System.EventHandler(this.gunaLabel2_Click);
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(31, 30);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(168, 28);
            this.gunaLabel1.TabIndex = 0;
            this.gunaLabel1.Text = "Total Pemasukan";
            // 
            // gunaShadowPanel2
            // 
            this.gunaShadowPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel2.BaseColor = System.Drawing.Color.White;
            this.gunaShadowPanel2.Controls.Add(this.gunaTransfarantPictureBox2);
            this.gunaShadowPanel2.Controls.Add(this.gunaLabelTglPengeluaran);
            this.gunaShadowPanel2.Controls.Add(this.gunaLabeTransPengeluaran);
            this.gunaShadowPanel2.Controls.Add(this.gunaLabel6);
            this.gunaShadowPanel2.Controls.Add(this.gunaLabelJmlPengeluaran);
            this.gunaShadowPanel2.Controls.Add(this.gunaLabel8);
            this.gunaShadowPanel2.Location = new System.Drawing.Point(70, 490);
            this.gunaShadowPanel2.Name = "gunaShadowPanel2";
            this.gunaShadowPanel2.Radius = 10;
            this.gunaShadowPanel2.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel2.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel2.Size = new System.Drawing.Size(439, 278);
            this.gunaShadowPanel2.TabIndex = 1;
            // 
            // gunaTransfarantPictureBox2
            // 
            this.gunaTransfarantPictureBox2.BaseColor = System.Drawing.Color.Black;
            this.gunaTransfarantPictureBox2.Image = global::ProjekAkhir.Properties.Resources.expensive_price_50px1_1;
            this.gunaTransfarantPictureBox2.Location = new System.Drawing.Point(301, 83);
            this.gunaTransfarantPictureBox2.Name = "gunaTransfarantPictureBox2";
            this.gunaTransfarantPictureBox2.Size = new System.Drawing.Size(96, 96);
            this.gunaTransfarantPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaTransfarantPictureBox2.TabIndex = 11;
            this.gunaTransfarantPictureBox2.TabStop = false;
            // 
            // gunaLabelTglPengeluaran
            // 
            this.gunaLabelTglPengeluaran.AutoSize = true;
            this.gunaLabelTglPengeluaran.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTglPengeluaran.Location = new System.Drawing.Point(169, 228);
            this.gunaLabelTglPengeluaran.Name = "gunaLabelTglPengeluaran";
            this.gunaLabelTglPengeluaran.Size = new System.Drawing.Size(170, 21);
            this.gunaLabelTglPengeluaran.TabIndex = 10;
            this.gunaLabelTglPengeluaran.Text = "TglTerakhirPengeluaran";
            // 
            // gunaLabeTransPengeluaran
            // 
            this.gunaLabeTransPengeluaran.AutoSize = true;
            this.gunaLabeTransPengeluaran.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabeTransPengeluaran.Location = new System.Drawing.Point(48, 183);
            this.gunaLabeTransPengeluaran.Name = "gunaLabeTransPengeluaran";
            this.gunaLabeTransPengeluaran.Size = new System.Drawing.Size(97, 21);
            this.gunaLabeTransPengeluaran.TabIndex = 9;
            this.gunaLabeTransPengeluaran.Text = "JmlTransaksi";
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel6.Location = new System.Drawing.Point(48, 142);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(74, 21);
            this.gunaLabel6.TabIndex = 8;
            this.gunaLabel6.Text = "Transaksi";
            // 
            // gunaLabelJmlPengeluaran
            // 
            this.gunaLabelJmlPengeluaran.AutoSize = true;
            this.gunaLabelJmlPengeluaran.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelJmlPengeluaran.Location = new System.Drawing.Point(48, 83);
            this.gunaLabelJmlPengeluaran.Name = "gunaLabelJmlPengeluaran";
            this.gunaLabelJmlPengeluaran.Size = new System.Drawing.Size(119, 21);
            this.gunaLabelJmlPengeluaran.TabIndex = 7;
            this.gunaLabelJmlPengeluaran.Text = "JmlPengeluaran";
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel8.Location = new System.Drawing.Point(41, 30);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(178, 28);
            this.gunaLabel8.TabIndex = 6;
            this.gunaLabel8.Text = "Total Pengeluaran";
            // 
            // gunaShadowPanel3
            // 
            this.gunaShadowPanel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel3.BaseColor = System.Drawing.Color.White;
            this.gunaShadowPanel3.Controls.Add(this.gunaLabelPemasukanMax);
            this.gunaShadowPanel3.Controls.Add(this.gunaLabel3);
            this.gunaShadowPanel3.Location = new System.Drawing.Point(546, 120);
            this.gunaShadowPanel3.Name = "gunaShadowPanel3";
            this.gunaShadowPanel3.Radius = 10;
            this.gunaShadowPanel3.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel3.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel3.Size = new System.Drawing.Size(279, 136);
            this.gunaShadowPanel3.TabIndex = 1;
            // 
            // gunaLabelPemasukanMax
            // 
            this.gunaLabelPemasukanMax.AutoSize = true;
            this.gunaLabelPemasukanMax.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelPemasukanMax.Location = new System.Drawing.Point(80, 74);
            this.gunaLabelPemasukanMax.Name = "gunaLabelPemasukanMax";
            this.gunaLabelPemasukanMax.Size = new System.Drawing.Size(120, 21);
            this.gunaLabelPemasukanMax.TabIndex = 2;
            this.gunaLabelPemasukanMax.Text = "PemasukanMax";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel3.Location = new System.Drawing.Point(23, 16);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(203, 28);
            this.gunaLabel3.TabIndex = 1;
            this.gunaLabel3.Text = "Pemasukan Tertinggi";
            // 
            // gunaShadowPanel4
            // 
            this.gunaShadowPanel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel4.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel4.BaseColor = System.Drawing.Color.White;
            this.gunaShadowPanel4.Controls.Add(this.gunaLabelPemasukanMin);
            this.gunaShadowPanel4.Controls.Add(this.gunaLabel5);
            this.gunaShadowPanel4.Location = new System.Drawing.Point(546, 262);
            this.gunaShadowPanel4.Name = "gunaShadowPanel4";
            this.gunaShadowPanel4.Radius = 10;
            this.gunaShadowPanel4.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel4.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel4.Size = new System.Drawing.Size(279, 136);
            this.gunaShadowPanel4.TabIndex = 2;
            // 
            // gunaLabelPemasukanMin
            // 
            this.gunaLabelPemasukanMin.AutoSize = true;
            this.gunaLabelPemasukanMin.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelPemasukanMin.Location = new System.Drawing.Point(80, 74);
            this.gunaLabelPemasukanMin.Name = "gunaLabelPemasukanMin";
            this.gunaLabelPemasukanMin.Size = new System.Drawing.Size(118, 21);
            this.gunaLabelPemasukanMin.TabIndex = 4;
            this.gunaLabelPemasukanMin.Text = "PemasukanMin";
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel5.Location = new System.Drawing.Point(23, 16);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(209, 28);
            this.gunaLabel5.TabIndex = 3;
            this.gunaLabel5.Text = "Pemasukan Terendah";
            // 
            // gunaShadowPanel5
            // 
            this.gunaShadowPanel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel5.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel5.BaseColor = System.Drawing.Color.White;
            this.gunaShadowPanel5.Controls.Add(this.gunaLabelLastPemasukan);
            this.gunaShadowPanel5.Controls.Add(this.gunaLabel10);
            this.gunaShadowPanel5.Location = new System.Drawing.Point(841, 120);
            this.gunaShadowPanel5.Name = "gunaShadowPanel5";
            this.gunaShadowPanel5.Radius = 10;
            this.gunaShadowPanel5.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel5.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel5.Size = new System.Drawing.Size(279, 136);
            this.gunaShadowPanel5.TabIndex = 2;
            // 
            // gunaLabelLastPemasukan
            // 
            this.gunaLabelLastPemasukan.AutoSize = true;
            this.gunaLabelLastPemasukan.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelLastPemasukan.Location = new System.Drawing.Point(80, 74);
            this.gunaLabelLastPemasukan.Name = "gunaLabelLastPemasukan";
            this.gunaLabelLastPemasukan.Size = new System.Drawing.Size(118, 21);
            this.gunaLabelLastPemasukan.TabIndex = 4;
            this.gunaLabelLastPemasukan.Text = "LastPemasukan";
            // 
            // gunaLabel10
            // 
            this.gunaLabel10.AutoSize = true;
            this.gunaLabel10.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel10.Location = new System.Drawing.Point(27, 16);
            this.gunaLabel10.Name = "gunaLabel10";
            this.gunaLabel10.Size = new System.Drawing.Size(197, 28);
            this.gunaLabel10.TabIndex = 3;
            this.gunaLabel10.Text = "Pemasukan Terakhir";
            // 
            // gunaShadowPanel6
            // 
            this.gunaShadowPanel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel6.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel6.BaseColor = System.Drawing.Color.White;
            this.gunaShadowPanel6.Controls.Add(this.gunaLabel13);
            this.gunaShadowPanel6.Controls.Add(this.gunaLabel14);
            this.gunaShadowPanel6.Location = new System.Drawing.Point(841, 262);
            this.gunaShadowPanel6.Name = "gunaShadowPanel6";
            this.gunaShadowPanel6.Radius = 10;
            this.gunaShadowPanel6.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel6.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel6.Size = new System.Drawing.Size(279, 136);
            this.gunaShadowPanel6.TabIndex = 2;
            // 
            // gunaLabel13
            // 
            this.gunaLabel13.AutoSize = true;
            this.gunaLabel13.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel13.Location = new System.Drawing.Point(80, 74);
            this.gunaLabel13.Name = "gunaLabel13";
            this.gunaLabel13.Size = new System.Drawing.Size(79, 21);
            this.gunaLabel13.TabIndex = 6;
            this.gunaLabel13.Text = "TotalUang";
            // 
            // gunaLabel14
            // 
            this.gunaLabel14.AutoSize = true;
            this.gunaLabel14.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel14.Location = new System.Drawing.Point(102, 16);
            this.gunaLabel14.Name = "gunaLabel14";
            this.gunaLabel14.Size = new System.Drawing.Size(57, 28);
            this.gunaLabel14.TabIndex = 5;
            this.gunaLabel14.Text = "Total";
            // 
            // gunaShadowPanel7
            // 
            this.gunaShadowPanel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel7.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel7.BaseColor = System.Drawing.Color.White;
            this.gunaShadowPanel7.Controls.Add(this.gunaLabelPengeluaranMax);
            this.gunaShadowPanel7.Controls.Add(this.gunaLabel7);
            this.gunaShadowPanel7.Location = new System.Drawing.Point(546, 490);
            this.gunaShadowPanel7.Name = "gunaShadowPanel7";
            this.gunaShadowPanel7.Radius = 10;
            this.gunaShadowPanel7.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel7.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel7.Size = new System.Drawing.Size(279, 136);
            this.gunaShadowPanel7.TabIndex = 2;
            // 
            // gunaLabelPengeluaranMax
            // 
            this.gunaLabelPengeluaranMax.AutoSize = true;
            this.gunaLabelPengeluaranMax.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelPengeluaranMax.Location = new System.Drawing.Point(80, 74);
            this.gunaLabelPengeluaranMax.Name = "gunaLabelPengeluaranMax";
            this.gunaLabelPengeluaranMax.Size = new System.Drawing.Size(126, 21);
            this.gunaLabelPengeluaranMax.TabIndex = 4;
            this.gunaLabelPengeluaranMax.Text = "PengeluaranMax";
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.Location = new System.Drawing.Point(21, 16);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(213, 28);
            this.gunaLabel7.TabIndex = 3;
            this.gunaLabel7.Text = "Pengeluaran Tertinggi";
            // 
            // gunaShadowPanel8
            // 
            this.gunaShadowPanel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel8.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel8.BaseColor = System.Drawing.Color.White;
            this.gunaShadowPanel8.Controls.Add(this.gunaLabelPengeluaranMin);
            this.gunaShadowPanel8.Controls.Add(this.gunaLabel9);
            this.gunaShadowPanel8.Location = new System.Drawing.Point(546, 632);
            this.gunaShadowPanel8.Name = "gunaShadowPanel8";
            this.gunaShadowPanel8.Radius = 10;
            this.gunaShadowPanel8.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel8.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel8.Size = new System.Drawing.Size(279, 136);
            this.gunaShadowPanel8.TabIndex = 2;
            // 
            // gunaLabelPengeluaranMin
            // 
            this.gunaLabelPengeluaranMin.AutoSize = true;
            this.gunaLabelPengeluaranMin.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelPengeluaranMin.Location = new System.Drawing.Point(80, 74);
            this.gunaLabelPengeluaranMin.Name = "gunaLabelPengeluaranMin";
            this.gunaLabelPengeluaranMin.Size = new System.Drawing.Size(124, 21);
            this.gunaLabelPengeluaranMin.TabIndex = 6;
            this.gunaLabelPengeluaranMin.Text = "PengeluaranMin";
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.AutoSize = true;
            this.gunaLabel9.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel9.Location = new System.Drawing.Point(21, 16);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(219, 28);
            this.gunaLabel9.TabIndex = 5;
            this.gunaLabel9.Text = "Pengeluaran Terendah";
            // 
            // gunaShadowPanel9
            // 
            this.gunaShadowPanel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel9.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel9.BaseColor = System.Drawing.Color.White;
            this.gunaShadowPanel9.Controls.Add(this.gunaLabelLastPengeluaran);
            this.gunaShadowPanel9.Controls.Add(this.gunaLabel12);
            this.gunaShadowPanel9.Location = new System.Drawing.Point(841, 490);
            this.gunaShadowPanel9.Name = "gunaShadowPanel9";
            this.gunaShadowPanel9.Radius = 10;
            this.gunaShadowPanel9.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel9.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal;
            this.gunaShadowPanel9.Size = new System.Drawing.Size(279, 136);
            this.gunaShadowPanel9.TabIndex = 2;
            // 
            // gunaLabelLastPengeluaran
            // 
            this.gunaLabelLastPengeluaran.AutoSize = true;
            this.gunaLabelLastPengeluaran.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelLastPengeluaran.Location = new System.Drawing.Point(80, 74);
            this.gunaLabelLastPengeluaran.Name = "gunaLabelLastPengeluaran";
            this.gunaLabelLastPengeluaran.Size = new System.Drawing.Size(124, 21);
            this.gunaLabelLastPengeluaran.TabIndex = 6;
            this.gunaLabelLastPengeluaran.Text = "LastPengeluaran";
            // 
            // gunaLabel12
            // 
            this.gunaLabel12.AutoSize = true;
            this.gunaLabel12.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel12.Location = new System.Drawing.Point(24, 16);
            this.gunaLabel12.Name = "gunaLabel12";
            this.gunaLabel12.Size = new System.Drawing.Size(207, 28);
            this.gunaLabel12.TabIndex = 5;
            this.gunaLabel12.Text = "Pengeluaran Terakhir";
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1159, 896);
            this.Controls.Add(this.gunaShadowPanel9);
            this.Controls.Add(this.gunaShadowPanel8);
            this.Controls.Add(this.gunaShadowPanel7);
            this.Controls.Add(this.gunaShadowPanel6);
            this.Controls.Add(this.gunaShadowPanel5);
            this.Controls.Add(this.gunaShadowPanel4);
            this.Controls.Add(this.gunaShadowPanel3);
            this.Controls.Add(this.gunaShadowPanel2);
            this.Controls.Add(this.gunaShadowPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.gunaShadowPanel1.ResumeLayout(false);
            this.gunaShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaTransfarantPictureBox1)).EndInit();
            this.gunaShadowPanel2.ResumeLayout(false);
            this.gunaShadowPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaTransfarantPictureBox2)).EndInit();
            this.gunaShadowPanel3.ResumeLayout(false);
            this.gunaShadowPanel3.PerformLayout();
            this.gunaShadowPanel4.ResumeLayout(false);
            this.gunaShadowPanel4.PerformLayout();
            this.gunaShadowPanel5.ResumeLayout(false);
            this.gunaShadowPanel5.PerformLayout();
            this.gunaShadowPanel6.ResumeLayout(false);
            this.gunaShadowPanel6.PerformLayout();
            this.gunaShadowPanel7.ResumeLayout(false);
            this.gunaShadowPanel7.PerformLayout();
            this.gunaShadowPanel8.ResumeLayout(false);
            this.gunaShadowPanel8.PerformLayout();
            this.gunaShadowPanel9.ResumeLayout(false);
            this.gunaShadowPanel9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel1;
        private Guna.UI.WinForms.GunaLabel gunaLabelJmlPemasukan;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel2;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel3;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel4;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel5;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel6;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel7;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel8;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel9;
        private Guna.UI.WinForms.GunaLabel gunaLabelTransPemasukan;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaTransfarantPictureBox gunaTransfarantPictureBox1;
        private Guna.UI.WinForms.GunaLabel gunaLabelTglPemasukan;
        private Guna.UI.WinForms.GunaTransfarantPictureBox gunaTransfarantPictureBox2;
        private Guna.UI.WinForms.GunaLabel gunaLabelTglPengeluaran;
        private Guna.UI.WinForms.GunaLabel gunaLabeTransPengeluaran;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaLabel gunaLabelJmlPengeluaran;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaLabel gunaLabelPemasukanMax;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabelPemasukanMin;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaLabel gunaLabelLastPemasukan;
        private Guna.UI.WinForms.GunaLabel gunaLabel10;
        private Guna.UI.WinForms.GunaLabel gunaLabel13;
        private Guna.UI.WinForms.GunaLabel gunaLabel14;
        private Guna.UI.WinForms.GunaLabel gunaLabelPengeluaranMax;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaLabel gunaLabelPengeluaranMin;
        private Guna.UI.WinForms.GunaLabel gunaLabel9;
        private Guna.UI.WinForms.GunaLabel gunaLabelLastPengeluaran;
        private Guna.UI.WinForms.GunaLabel gunaLabel12;
    }
}