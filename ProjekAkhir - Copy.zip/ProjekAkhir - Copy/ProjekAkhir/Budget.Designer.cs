﻿namespace ProjekAkhir
{
    partial class Budget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabelTotPengeluaran = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabelTotPemasukan = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaShadowPanel1 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelTotMakanan = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaShadowPanel2 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelTotTransportasi = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaShadowPanel3 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelTotRumah = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaShadowPanel4 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelTotPerawatan = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox4 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaShadowPanel5 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelTotBelanja = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox5 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaShadowPanel6 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelTotKesehatan = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel11 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox6 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaShadowPanel7 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelTotPendidikan = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel10 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox7 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaShadowPanel8 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelTotGaji = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel12 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox8 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaShadowPanel9 = new Guna.UI.WinForms.GunaShadowPanel();
            this.gunaLabelTotInvestasi = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel13 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox9 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaImageButton1 = new Guna.UI.WinForms.GunaImageButton();
            this.gunaButtonBefore = new Guna.UI.WinForms.GunaButton();
            this.gunaButtonAfter = new Guna.UI.WinForms.GunaButton();
            this.gunaShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.gunaShadowPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            this.gunaShadowPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            this.gunaShadowPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).BeginInit();
            this.gunaShadowPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).BeginInit();
            this.gunaShadowPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).BeginInit();
            this.gunaShadowPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).BeginInit();
            this.gunaShadowPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).BeginInit();
            this.gunaShadowPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(512, 73);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(70, 21);
            this.gunaLabel1.TabIndex = 0;
            this.gunaLabel1.Text = "Bulan Ini";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(454, 114);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(123, 21);
            this.gunaLabel2.TabIndex = 3;
            this.gunaLabel2.Text = "Pengeluaran IDR";
            // 
            // gunaLabelTotPengeluaran
            // 
            this.gunaLabelTotPengeluaran.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLabelTotPengeluaran.AutoSize = true;
            this.gunaLabelTotPengeluaran.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotPengeluaran.Location = new System.Drawing.Point(593, 114);
            this.gunaLabelTotPengeluaran.Name = "gunaLabelTotPengeluaran";
            this.gunaLabelTotPengeluaran.Size = new System.Drawing.Size(37, 21);
            this.gunaLabelTotPengeluaran.TabIndex = 4;
            this.gunaLabelTotPengeluaran.Text = "000";
            // 
            // gunaLabelTotPemasukan
            // 
            this.gunaLabelTotPemasukan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLabelTotPemasukan.AutoSize = true;
            this.gunaLabelTotPemasukan.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotPemasukan.Location = new System.Drawing.Point(593, 575);
            this.gunaLabelTotPemasukan.Name = "gunaLabelTotPemasukan";
            this.gunaLabelTotPemasukan.Size = new System.Drawing.Size(37, 21);
            this.gunaLabelTotPemasukan.TabIndex = 6;
            this.gunaLabelTotPemasukan.Text = "000";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.Location = new System.Drawing.Point(462, 575);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(117, 21);
            this.gunaLabel4.TabIndex = 5;
            this.gunaLabel4.Text = "Pemasukan IDR";
            // 
            // gunaShadowPanel1
            // 
            this.gunaShadowPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(184)))));
            this.gunaShadowPanel1.Controls.Add(this.gunaLabelTotMakanan);
            this.gunaShadowPanel1.Controls.Add(this.gunaLabel3);
            this.gunaShadowPanel1.Controls.Add(this.gunaPictureBox1);
            this.gunaShadowPanel1.Location = new System.Drawing.Point(107, 152);
            this.gunaShadowPanel1.Name = "gunaShadowPanel1";
            this.gunaShadowPanel1.Radius = 10;
            this.gunaShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel1.ShadowDepth = 70;
            this.gunaShadowPanel1.ShadowShift = 4;
            this.gunaShadowPanel1.Size = new System.Drawing.Size(186, 192);
            this.gunaShadowPanel1.TabIndex = 7;
            // 
            // gunaLabelTotMakanan
            // 
            this.gunaLabelTotMakanan.AutoSize = true;
            this.gunaLabelTotMakanan.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotMakanan.Location = new System.Drawing.Point(31, 145);
            this.gunaLabelTotMakanan.Name = "gunaLabelTotMakanan";
            this.gunaLabelTotMakanan.Size = new System.Drawing.Size(93, 21);
            this.gunaLabelTotMakanan.TabIndex = 14;
            this.gunaLabelTotMakanan.Text = "RpMakanan";
            this.gunaLabelTotMakanan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel3.Location = new System.Drawing.Point(39, 20);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(109, 42);
            this.gunaLabel3.TabIndex = 13;
            this.gunaLabel3.Text = "Makanan dan \r\nMinuman";
            this.gunaLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::ProjekAkhir.Properties.Resources.food_50pxs_1;
            this.gunaPictureBox1.Location = new System.Drawing.Point(66, 71);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(50, 50);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox1.TabIndex = 0;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaShadowPanel2
            // 
            this.gunaShadowPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(203)))), ((int)(((byte)(255)))));
            this.gunaShadowPanel2.Controls.Add(this.gunaLabelTotTransportasi);
            this.gunaShadowPanel2.Controls.Add(this.gunaLabel7);
            this.gunaShadowPanel2.Controls.Add(this.gunaPictureBox2);
            this.gunaShadowPanel2.Location = new System.Drawing.Point(358, 152);
            this.gunaShadowPanel2.Name = "gunaShadowPanel2";
            this.gunaShadowPanel2.Radius = 10;
            this.gunaShadowPanel2.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel2.ShadowDepth = 70;
            this.gunaShadowPanel2.ShadowShift = 4;
            this.gunaShadowPanel2.Size = new System.Drawing.Size(186, 192);
            this.gunaShadowPanel2.TabIndex = 8;
            // 
            // gunaLabelTotTransportasi
            // 
            this.gunaLabelTotTransportasi.AutoSize = true;
            this.gunaLabelTotTransportasi.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotTransportasi.Location = new System.Drawing.Point(31, 145);
            this.gunaLabelTotTransportasi.Name = "gunaLabelTotTransportasi";
            this.gunaLabelTotTransportasi.Size = new System.Drawing.Size(114, 21);
            this.gunaLabelTotTransportasi.TabIndex = 17;
            this.gunaLabelTotTransportasi.Text = "RpTransportasi";
            this.gunaLabelTotTransportasi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.Location = new System.Drawing.Point(47, 20);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(96, 21);
            this.gunaLabel7.TabIndex = 16;
            this.gunaLabel7.Text = "Transportasi";
            this.gunaLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Image = global::ProjekAkhir.Properties.Resources.transportation_50px1_1;
            this.gunaPictureBox2.Location = new System.Drawing.Point(66, 71);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(50, 50);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox2.TabIndex = 15;
            this.gunaPictureBox2.TabStop = false;
            // 
            // gunaShadowPanel3
            // 
            this.gunaShadowPanel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(215)))), ((int)(((byte)(166)))));
            this.gunaShadowPanel3.Controls.Add(this.gunaLabelTotRumah);
            this.gunaShadowPanel3.Controls.Add(this.gunaLabel6);
            this.gunaShadowPanel3.Controls.Add(this.gunaPictureBox3);
            this.gunaShadowPanel3.Location = new System.Drawing.Point(609, 152);
            this.gunaShadowPanel3.Name = "gunaShadowPanel3";
            this.gunaShadowPanel3.Radius = 10;
            this.gunaShadowPanel3.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel3.ShadowDepth = 70;
            this.gunaShadowPanel3.ShadowShift = 4;
            this.gunaShadowPanel3.Size = new System.Drawing.Size(186, 192);
            this.gunaShadowPanel3.TabIndex = 9;
            // 
            // gunaLabelTotRumah
            // 
            this.gunaLabelTotRumah.AutoSize = true;
            this.gunaLabelTotRumah.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotRumah.Location = new System.Drawing.Point(31, 145);
            this.gunaLabelTotRumah.Name = "gunaLabelTotRumah";
            this.gunaLabelTotRumah.Size = new System.Drawing.Size(86, 21);
            this.gunaLabelTotRumah.TabIndex = 17;
            this.gunaLabelTotRumah.Text = "RpKRumah";
            this.gunaLabelTotRumah.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel6.Location = new System.Drawing.Point(51, 20);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(90, 42);
            this.gunaLabel6.TabIndex = 16;
            this.gunaLabel6.Text = "Kebutuhan \r\nRumah";
            this.gunaLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPictureBox3
            // 
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox3.Image = global::ProjekAkhir.Properties.Resources.equal_housing_opportunity_50px1_1;
            this.gunaPictureBox3.Location = new System.Drawing.Point(66, 71);
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.Size = new System.Drawing.Size(50, 50);
            this.gunaPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox3.TabIndex = 15;
            this.gunaPictureBox3.TabStop = false;
            // 
            // gunaShadowPanel4
            // 
            this.gunaShadowPanel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel4.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(200)))), ((int)(((byte)(246)))));
            this.gunaShadowPanel4.Controls.Add(this.gunaLabelTotPerawatan);
            this.gunaShadowPanel4.Controls.Add(this.gunaLabel8);
            this.gunaShadowPanel4.Controls.Add(this.gunaPictureBox4);
            this.gunaShadowPanel4.Location = new System.Drawing.Point(860, 152);
            this.gunaShadowPanel4.Name = "gunaShadowPanel4";
            this.gunaShadowPanel4.Radius = 10;
            this.gunaShadowPanel4.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel4.ShadowDepth = 70;
            this.gunaShadowPanel4.ShadowShift = 4;
            this.gunaShadowPanel4.Size = new System.Drawing.Size(186, 192);
            this.gunaShadowPanel4.TabIndex = 10;
            // 
            // gunaLabelTotPerawatan
            // 
            this.gunaLabelTotPerawatan.AutoSize = true;
            this.gunaLabelTotPerawatan.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotPerawatan.Location = new System.Drawing.Point(31, 145);
            this.gunaLabelTotPerawatan.Name = "gunaLabelTotPerawatan";
            this.gunaLabelTotPerawatan.Size = new System.Drawing.Size(46, 21);
            this.gunaLabelTotPerawatan.TabIndex = 17;
            this.gunaLabelTotPerawatan.Text = "RpPP";
            this.gunaLabelTotPerawatan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel8.Location = new System.Drawing.Point(50, 20);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(84, 42);
            this.gunaLabel8.TabIndex = 16;
            this.gunaLabel8.Text = "Perawatan\r\nPribadi";
            this.gunaLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPictureBox4
            // 
            this.gunaPictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox4.Image = global::ProjekAkhir.Properties.Resources.food_50pxs_1;
            this.gunaPictureBox4.Location = new System.Drawing.Point(66, 71);
            this.gunaPictureBox4.Name = "gunaPictureBox4";
            this.gunaPictureBox4.Size = new System.Drawing.Size(50, 50);
            this.gunaPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox4.TabIndex = 15;
            this.gunaPictureBox4.TabStop = false;
            // 
            // gunaShadowPanel5
            // 
            this.gunaShadowPanel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel5.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(177)))), ((int)(((byte)(178)))));
            this.gunaShadowPanel5.Controls.Add(this.gunaLabelTotBelanja);
            this.gunaShadowPanel5.Controls.Add(this.gunaLabel9);
            this.gunaShadowPanel5.Controls.Add(this.gunaPictureBox5);
            this.gunaShadowPanel5.Location = new System.Drawing.Point(107, 368);
            this.gunaShadowPanel5.Name = "gunaShadowPanel5";
            this.gunaShadowPanel5.Radius = 10;
            this.gunaShadowPanel5.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel5.ShadowDepth = 70;
            this.gunaShadowPanel5.ShadowShift = 4;
            this.gunaShadowPanel5.Size = new System.Drawing.Size(186, 192);
            this.gunaShadowPanel5.TabIndex = 11;
            // 
            // gunaLabelTotBelanja
            // 
            this.gunaLabelTotBelanja.AutoSize = true;
            this.gunaLabelTotBelanja.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotBelanja.Location = new System.Drawing.Point(31, 145);
            this.gunaLabelTotBelanja.Name = "gunaLabelTotBelanja";
            this.gunaLabelTotBelanja.Size = new System.Drawing.Size(78, 21);
            this.gunaLabelTotBelanja.TabIndex = 17;
            this.gunaLabelTotBelanja.Text = "RpBelanja";
            this.gunaLabelTotBelanja.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.AutoSize = true;
            this.gunaLabel9.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel9.Location = new System.Drawing.Point(61, 20);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(60, 21);
            this.gunaLabel9.TabIndex = 16;
            this.gunaLabel9.Text = "Belanja";
            this.gunaLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPictureBox5
            // 
            this.gunaPictureBox5.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox5.Image = global::ProjekAkhir.Properties.Resources.shopping_50px_2;
            this.gunaPictureBox5.Location = new System.Drawing.Point(66, 71);
            this.gunaPictureBox5.Name = "gunaPictureBox5";
            this.gunaPictureBox5.Size = new System.Drawing.Size(50, 50);
            this.gunaPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox5.TabIndex = 15;
            this.gunaPictureBox5.TabStop = false;
            // 
            // gunaShadowPanel6
            // 
            this.gunaShadowPanel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel6.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(245)))), ((int)(((byte)(216)))));
            this.gunaShadowPanel6.Controls.Add(this.gunaLabelTotKesehatan);
            this.gunaShadowPanel6.Controls.Add(this.gunaLabel11);
            this.gunaShadowPanel6.Controls.Add(this.gunaPictureBox6);
            this.gunaShadowPanel6.Location = new System.Drawing.Point(358, 368);
            this.gunaShadowPanel6.Name = "gunaShadowPanel6";
            this.gunaShadowPanel6.Radius = 10;
            this.gunaShadowPanel6.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel6.ShadowDepth = 70;
            this.gunaShadowPanel6.ShadowShift = 4;
            this.gunaShadowPanel6.Size = new System.Drawing.Size(186, 192);
            this.gunaShadowPanel6.TabIndex = 10;
            // 
            // gunaLabelTotKesehatan
            // 
            this.gunaLabelTotKesehatan.AutoSize = true;
            this.gunaLabelTotKesehatan.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotKesehatan.Location = new System.Drawing.Point(31, 145);
            this.gunaLabelTotKesehatan.Name = "gunaLabelTotKesehatan";
            this.gunaLabelTotKesehatan.Size = new System.Drawing.Size(100, 21);
            this.gunaLabelTotKesehatan.TabIndex = 17;
            this.gunaLabelTotKesehatan.Text = "RpKesehatan";
            this.gunaLabelTotKesehatan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel11
            // 
            this.gunaLabel11.AutoSize = true;
            this.gunaLabel11.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel11.Location = new System.Drawing.Point(52, 20);
            this.gunaLabel11.Name = "gunaLabel11";
            this.gunaLabel11.Size = new System.Drawing.Size(82, 21);
            this.gunaLabel11.TabIndex = 16;
            this.gunaLabel11.Text = "Kesehatan";
            this.gunaLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPictureBox6
            // 
            this.gunaPictureBox6.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox6.Image = global::ProjekAkhir.Properties.Resources.doctors_bag_50px_1;
            this.gunaPictureBox6.Location = new System.Drawing.Point(66, 71);
            this.gunaPictureBox6.Name = "gunaPictureBox6";
            this.gunaPictureBox6.Size = new System.Drawing.Size(50, 50);
            this.gunaPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox6.TabIndex = 15;
            this.gunaPictureBox6.TabStop = false;
            // 
            // gunaShadowPanel7
            // 
            this.gunaShadowPanel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel7.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(185)))), ((int)(((byte)(227)))));
            this.gunaShadowPanel7.Controls.Add(this.gunaLabelTotPendidikan);
            this.gunaShadowPanel7.Controls.Add(this.gunaLabel10);
            this.gunaShadowPanel7.Controls.Add(this.gunaPictureBox7);
            this.gunaShadowPanel7.Location = new System.Drawing.Point(609, 368);
            this.gunaShadowPanel7.Name = "gunaShadowPanel7";
            this.gunaShadowPanel7.Radius = 10;
            this.gunaShadowPanel7.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel7.ShadowDepth = 70;
            this.gunaShadowPanel7.ShadowShift = 4;
            this.gunaShadowPanel7.Size = new System.Drawing.Size(186, 192);
            this.gunaShadowPanel7.TabIndex = 10;
            // 
            // gunaLabelTotPendidikan
            // 
            this.gunaLabelTotPendidikan.AutoSize = true;
            this.gunaLabelTotPendidikan.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotPendidikan.Location = new System.Drawing.Point(31, 145);
            this.gunaLabelTotPendidikan.Name = "gunaLabelTotPendidikan";
            this.gunaLabelTotPendidikan.Size = new System.Drawing.Size(105, 21);
            this.gunaLabelTotPendidikan.TabIndex = 17;
            this.gunaLabelTotPendidikan.Text = "RpPendidikan";
            this.gunaLabelTotPendidikan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel10
            // 
            this.gunaLabel10.AutoSize = true;
            this.gunaLabel10.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel10.Location = new System.Drawing.Point(52, 20);
            this.gunaLabel10.Name = "gunaLabel10";
            this.gunaLabel10.Size = new System.Drawing.Size(87, 21);
            this.gunaLabel10.TabIndex = 16;
            this.gunaLabel10.Text = "Pendidikan";
            this.gunaLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPictureBox7
            // 
            this.gunaPictureBox7.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox7.Image = global::ProjekAkhir.Properties.Resources.graduation_cap_50px_1;
            this.gunaPictureBox7.Location = new System.Drawing.Point(66, 71);
            this.gunaPictureBox7.Name = "gunaPictureBox7";
            this.gunaPictureBox7.Size = new System.Drawing.Size(50, 50);
            this.gunaPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox7.TabIndex = 15;
            this.gunaPictureBox7.TabStop = false;
            // 
            // gunaShadowPanel8
            // 
            this.gunaShadowPanel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel8.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel8.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(252)))), ((int)(((byte)(191)))));
            this.gunaShadowPanel8.Controls.Add(this.gunaLabelTotGaji);
            this.gunaShadowPanel8.Controls.Add(this.gunaLabel12);
            this.gunaShadowPanel8.Controls.Add(this.gunaPictureBox8);
            this.gunaShadowPanel8.Location = new System.Drawing.Point(107, 615);
            this.gunaShadowPanel8.Name = "gunaShadowPanel8";
            this.gunaShadowPanel8.Radius = 10;
            this.gunaShadowPanel8.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel8.ShadowDepth = 70;
            this.gunaShadowPanel8.ShadowShift = 4;
            this.gunaShadowPanel8.Size = new System.Drawing.Size(186, 192);
            this.gunaShadowPanel8.TabIndex = 11;
            // 
            // gunaLabelTotGaji
            // 
            this.gunaLabelTotGaji.AutoSize = true;
            this.gunaLabelTotGaji.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotGaji.Location = new System.Drawing.Point(31, 145);
            this.gunaLabelTotGaji.Name = "gunaLabelTotGaji";
            this.gunaLabelTotGaji.Size = new System.Drawing.Size(55, 21);
            this.gunaLabelTotGaji.TabIndex = 17;
            this.gunaLabelTotGaji.Text = "RpGaji";
            this.gunaLabelTotGaji.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel12
            // 
            this.gunaLabel12.AutoSize = true;
            this.gunaLabel12.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel12.Location = new System.Drawing.Point(72, 20);
            this.gunaLabel12.Name = "gunaLabel12";
            this.gunaLabel12.Size = new System.Drawing.Size(37, 21);
            this.gunaLabel12.TabIndex = 16;
            this.gunaLabel12.Text = "Gaji";
            this.gunaLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPictureBox8
            // 
            this.gunaPictureBox8.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox8.Image = global::ProjekAkhir.Properties.Resources.money_transfer_50px_1;
            this.gunaPictureBox8.Location = new System.Drawing.Point(66, 71);
            this.gunaPictureBox8.Name = "gunaPictureBox8";
            this.gunaPictureBox8.Size = new System.Drawing.Size(50, 50);
            this.gunaPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox8.TabIndex = 15;
            this.gunaPictureBox8.TabStop = false;
            // 
            // gunaShadowPanel9
            // 
            this.gunaShadowPanel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaShadowPanel9.BackColor = System.Drawing.Color.Transparent;
            this.gunaShadowPanel9.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(245)))), ((int)(((byte)(188)))));
            this.gunaShadowPanel9.Controls.Add(this.gunaLabelTotInvestasi);
            this.gunaShadowPanel9.Controls.Add(this.gunaLabel13);
            this.gunaShadowPanel9.Controls.Add(this.gunaPictureBox9);
            this.gunaShadowPanel9.Location = new System.Drawing.Point(358, 613);
            this.gunaShadowPanel9.Name = "gunaShadowPanel9";
            this.gunaShadowPanel9.Radius = 10;
            this.gunaShadowPanel9.ShadowColor = System.Drawing.Color.Black;
            this.gunaShadowPanel9.ShadowDepth = 70;
            this.gunaShadowPanel9.ShadowShift = 4;
            this.gunaShadowPanel9.Size = new System.Drawing.Size(186, 192);
            this.gunaShadowPanel9.TabIndex = 12;
            // 
            // gunaLabelTotInvestasi
            // 
            this.gunaLabelTotInvestasi.AutoSize = true;
            this.gunaLabelTotInvestasi.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabelTotInvestasi.Location = new System.Drawing.Point(31, 145);
            this.gunaLabelTotInvestasi.Name = "gunaLabelTotInvestasi";
            this.gunaLabelTotInvestasi.Size = new System.Drawing.Size(89, 21);
            this.gunaLabelTotInvestasi.TabIndex = 17;
            this.gunaLabelTotInvestasi.Text = "RpInvestasi";
            this.gunaLabelTotInvestasi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel13
            // 
            this.gunaLabel13.AutoSize = true;
            this.gunaLabel13.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel13.Location = new System.Drawing.Point(57, 20);
            this.gunaLabel13.Name = "gunaLabel13";
            this.gunaLabel13.Size = new System.Drawing.Size(71, 21);
            this.gunaLabel13.TabIndex = 16;
            this.gunaLabel13.Text = "Investasi";
            this.gunaLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPictureBox9
            // 
            this.gunaPictureBox9.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox9.Image = global::ProjekAkhir.Properties.Resources.money_bag_50px_1;
            this.gunaPictureBox9.Location = new System.Drawing.Point(66, 71);
            this.gunaPictureBox9.Name = "gunaPictureBox9";
            this.gunaPictureBox9.Size = new System.Drawing.Size(50, 50);
            this.gunaPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox9.TabIndex = 15;
            this.gunaPictureBox9.TabStop = false;
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel5.Location = new System.Drawing.Point(891, 388);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(133, 21);
            this.gunaLabel5.TabIndex = 17;
            this.gunaLabel5.Text = "Tambah Transaksi";
            this.gunaLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaImageButton1
            // 
            this.gunaImageButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaImageButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaImageButton1.Image = global::ProjekAkhir.Properties.Resources.Plus_512px;
            this.gunaImageButton1.ImageSize = new System.Drawing.Size(64, 64);
            this.gunaImageButton1.Location = new System.Drawing.Point(917, 436);
            this.gunaImageButton1.Name = "gunaImageButton1";
            this.gunaImageButton1.OnHoverImage = null;
            this.gunaImageButton1.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.gunaImageButton1.Size = new System.Drawing.Size(82, 73);
            this.gunaImageButton1.TabIndex = 18;
            this.gunaImageButton1.Click += new System.EventHandler(this.gunaImageButton1_Click);
            // 
            // gunaButtonBefore
            // 
            this.gunaButtonBefore.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButtonBefore.AnimationHoverSpeed = 0.07F;
            this.gunaButtonBefore.AnimationSpeed = 0.03F;
            this.gunaButtonBefore.BackColor = System.Drawing.Color.Transparent;
            this.gunaButtonBefore.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gunaButtonBefore.BorderColor = System.Drawing.Color.Black;
            this.gunaButtonBefore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButtonBefore.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButtonBefore.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButtonBefore.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButtonBefore.ForeColor = System.Drawing.Color.White;
            this.gunaButtonBefore.Image = global::ProjekAkhir.Properties.Resources.left;
            this.gunaButtonBefore.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButtonBefore.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButtonBefore.Location = new System.Drawing.Point(478, 69);
            this.gunaButtonBefore.Name = "gunaButtonBefore";
            this.gunaButtonBefore.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(140)))), ((int)(((byte)(190)))));
            this.gunaButtonBefore.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButtonBefore.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButtonBefore.OnHoverImage = null;
            this.gunaButtonBefore.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButtonBefore.OnPressedDepth = 15;
            this.gunaButtonBefore.Radius = 5;
            this.gunaButtonBefore.Size = new System.Drawing.Size(28, 30);
            this.gunaButtonBefore.TabIndex = 2;
            // 
            // gunaButtonAfter
            // 
            this.gunaButtonAfter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaButtonAfter.AnimationHoverSpeed = 0.07F;
            this.gunaButtonAfter.AnimationSpeed = 0.03F;
            this.gunaButtonAfter.BackColor = System.Drawing.Color.Transparent;
            this.gunaButtonAfter.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gunaButtonAfter.BorderColor = System.Drawing.Color.Black;
            this.gunaButtonAfter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButtonAfter.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButtonAfter.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButtonAfter.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButtonAfter.ForeColor = System.Drawing.Color.White;
            this.gunaButtonAfter.Image = global::ProjekAkhir.Properties.Resources.Right;
            this.gunaButtonAfter.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButtonAfter.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButtonAfter.Location = new System.Drawing.Point(588, 69);
            this.gunaButtonAfter.Name = "gunaButtonAfter";
            this.gunaButtonAfter.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(140)))), ((int)(((byte)(190)))));
            this.gunaButtonAfter.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButtonAfter.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButtonAfter.OnHoverImage = null;
            this.gunaButtonAfter.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButtonAfter.OnPressedDepth = 15;
            this.gunaButtonAfter.Radius = 5;
            this.gunaButtonAfter.Size = new System.Drawing.Size(28, 30);
            this.gunaButtonAfter.TabIndex = 1;
            // 
            // Budget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1159, 896);
            this.Controls.Add(this.gunaImageButton1);
            this.Controls.Add(this.gunaLabel5);
            this.Controls.Add(this.gunaShadowPanel9);
            this.Controls.Add(this.gunaShadowPanel8);
            this.Controls.Add(this.gunaShadowPanel7);
            this.Controls.Add(this.gunaShadowPanel6);
            this.Controls.Add(this.gunaShadowPanel5);
            this.Controls.Add(this.gunaShadowPanel4);
            this.Controls.Add(this.gunaShadowPanel3);
            this.Controls.Add(this.gunaShadowPanel2);
            this.Controls.Add(this.gunaShadowPanel1);
            this.Controls.Add(this.gunaLabelTotPemasukan);
            this.Controls.Add(this.gunaLabel4);
            this.Controls.Add(this.gunaLabelTotPengeluaran);
            this.Controls.Add(this.gunaLabel2);
            this.Controls.Add(this.gunaButtonBefore);
            this.Controls.Add(this.gunaButtonAfter);
            this.Controls.Add(this.gunaLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Budget";
            this.Text = "Budget";
            this.gunaShadowPanel1.ResumeLayout(false);
            this.gunaShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.gunaShadowPanel2.ResumeLayout(false);
            this.gunaShadowPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            this.gunaShadowPanel3.ResumeLayout(false);
            this.gunaShadowPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            this.gunaShadowPanel4.ResumeLayout(false);
            this.gunaShadowPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).EndInit();
            this.gunaShadowPanel5.ResumeLayout(false);
            this.gunaShadowPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).EndInit();
            this.gunaShadowPanel6.ResumeLayout(false);
            this.gunaShadowPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).EndInit();
            this.gunaShadowPanel7.ResumeLayout(false);
            this.gunaShadowPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).EndInit();
            this.gunaShadowPanel8.ResumeLayout(false);
            this.gunaShadowPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).EndInit();
            this.gunaShadowPanel9.ResumeLayout(false);
            this.gunaShadowPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaButton gunaButtonAfter;
        private Guna.UI.WinForms.GunaButton gunaButtonBefore;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotPengeluaran;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotPemasukan;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel1;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel2;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel3;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel4;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel5;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel6;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel7;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel8;
        private Guna.UI.WinForms.GunaShadowPanel gunaShadowPanel9;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotMakanan;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotTransportasi;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotRumah;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotPerawatan;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox4;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotBelanja;
        private Guna.UI.WinForms.GunaLabel gunaLabel9;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox5;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotKesehatan;
        private Guna.UI.WinForms.GunaLabel gunaLabel11;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox6;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotPendidikan;
        private Guna.UI.WinForms.GunaLabel gunaLabel10;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox7;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotGaji;
        private Guna.UI.WinForms.GunaLabel gunaLabel12;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox8;
        private Guna.UI.WinForms.GunaLabel gunaLabelTotInvestasi;
        private Guna.UI.WinForms.GunaLabel gunaLabel13;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox9;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaImageButton gunaImageButton1;
    }
}