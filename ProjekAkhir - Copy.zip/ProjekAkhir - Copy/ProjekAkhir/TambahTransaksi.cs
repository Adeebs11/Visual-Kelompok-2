﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjekAkhir
{
    public partial class TambahTransaksi : Form
    {
        public TambahTransaksi()
        {
            InitializeComponent();
        }

        private void gunaBtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
