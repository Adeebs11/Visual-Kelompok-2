﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjekAkhir
{
    public partial class Transaksi : Form
    {
        public Transaksi()
        {
            InitializeComponent();
            
        }

        private void Transaksi_Shown(object sender, EventArgs e)
        {
            gunaDataGridView1.Rows.Add(new object[]
            {
                "Pemasukan Harian",
                "Gaji",
                "5 Mei 2022",
                "10000",
                "Geprek"
            }
            );
            gunaDataGridView1.Rows.Add(new object[]
            {
                "Pemasukan Harian",
                "Gaji",
                "5 Mei 2022",
                "10000",
                "Geprek"
            }
            );
        }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
