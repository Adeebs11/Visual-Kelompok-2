﻿namespace ProjekAkhir
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.gunaTransfarantPictureBox3 = new Guna.UI.WinForms.GunaTransfarantPictureBox();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.gunaButtonBudget = new Guna.UI.WinForms.GunaButton();
            this.gunaButtonTransaksi = new Guna.UI.WinForms.GunaButton();
            this.gunaButtonBeranda = new Guna.UI.WinForms.GunaButton();
            this.gunaPanelContainer = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaTransfarantPictureBox3)).BeginInit();
            this.gunaPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(175)))), ((int)(((byte)(216)))));
            this.gunaPanel1.Controls.Add(this.gunaTransfarantPictureBox3);
            this.gunaPanel1.Controls.Add(this.gunaLabel1);
            this.gunaPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel1.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(1440, 88);
            this.gunaPanel1.TabIndex = 10;
            // 
            // gunaTransfarantPictureBox3
            // 
            this.gunaTransfarantPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.gunaTransfarantPictureBox3.BaseColor = System.Drawing.Color.Black;
            this.gunaTransfarantPictureBox3.Image = global::ProjekAkhir.Properties.Resources._20230512_202814_0000;
            this.gunaTransfarantPictureBox3.Location = new System.Drawing.Point(12, 9);
            this.gunaTransfarantPictureBox3.Name = "gunaTransfarantPictureBox3";
            this.gunaTransfarantPictureBox3.Size = new System.Drawing.Size(72, 66);
            this.gunaTransfarantPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaTransfarantPictureBox3.TabIndex = 11;
            this.gunaTransfarantPictureBox3.TabStop = false;
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Calibri", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.ForeColor = System.Drawing.Color.White;
            this.gunaLabel1.Location = new System.Drawing.Point(90, 21);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(133, 45);
            this.gunaLabel1.TabIndex = 10;
            this.gunaLabel1.Text = "SakuKu";
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.gunaPanel2.Controls.Add(this.gunaButtonBudget);
            this.gunaPanel2.Controls.Add(this.gunaButtonTransaksi);
            this.gunaPanel2.Controls.Add(this.gunaButtonBeranda);
            this.gunaPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaPanel2.Location = new System.Drawing.Point(0, 88);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(281, 896);
            this.gunaPanel2.TabIndex = 11;
            // 
            // gunaButtonBudget
            // 
            this.gunaButtonBudget.AnimationHoverSpeed = 0.07F;
            this.gunaButtonBudget.AnimationSpeed = 0.03F;
            this.gunaButtonBudget.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.gunaButtonBudget.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.gunaButtonBudget.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButtonBudget.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButtonBudget.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButtonBudget.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButtonBudget.ForeColor = System.Drawing.Color.White;
            this.gunaButtonBudget.Image = global::ProjekAkhir.Properties.Resources.transaction_50px1f_1__1_;
            this.gunaButtonBudget.ImageSize = new System.Drawing.Size(35, 35);
            this.gunaButtonBudget.Location = new System.Drawing.Point(0, 195);
            this.gunaButtonBudget.Name = "gunaButtonBudget";
            this.gunaButtonBudget.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(130)))), ((int)(((byte)(246)))));
            this.gunaButtonBudget.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButtonBudget.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButtonBudget.OnHoverImage = null;
            this.gunaButtonBudget.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButtonBudget.Size = new System.Drawing.Size(281, 59);
            this.gunaButtonBudget.TabIndex = 2;
            this.gunaButtonBudget.Text = "Budget";
            this.gunaButtonBudget.TextOffsetX = 18;
            this.gunaButtonBudget.Click += new System.EventHandler(this.gunaButtonBudget_Click);
            // 
            // gunaButtonTransaksi
            // 
            this.gunaButtonTransaksi.AnimationHoverSpeed = 0.07F;
            this.gunaButtonTransaksi.AnimationSpeed = 0.03F;
            this.gunaButtonTransaksi.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.gunaButtonTransaksi.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.gunaButtonTransaksi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButtonTransaksi.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButtonTransaksi.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButtonTransaksi.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButtonTransaksi.ForeColor = System.Drawing.Color.White;
            this.gunaButtonTransaksi.Image = global::ProjekAkhir.Properties.Resources.transaction_list_50px_1__1_;
            this.gunaButtonTransaksi.ImageSize = new System.Drawing.Size(35, 35);
            this.gunaButtonTransaksi.Location = new System.Drawing.Point(0, 285);
            this.gunaButtonTransaksi.Name = "gunaButtonTransaksi";
            this.gunaButtonTransaksi.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(130)))), ((int)(((byte)(246)))));
            this.gunaButtonTransaksi.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButtonTransaksi.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButtonTransaksi.OnHoverImage = null;
            this.gunaButtonTransaksi.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButtonTransaksi.Size = new System.Drawing.Size(281, 59);
            this.gunaButtonTransaksi.TabIndex = 1;
            this.gunaButtonTransaksi.Text = "Transaksi";
            this.gunaButtonTransaksi.TextOffsetX = 18;
            this.gunaButtonTransaksi.Click += new System.EventHandler(this.gunaButtonTransaksi_Click);
            // 
            // gunaButtonBeranda
            // 
            this.gunaButtonBeranda.AnimationHoverSpeed = 0.07F;
            this.gunaButtonBeranda.AnimationSpeed = 0.03F;
            this.gunaButtonBeranda.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.gunaButtonBeranda.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.gunaButtonBeranda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButtonBeranda.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButtonBeranda.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButtonBeranda.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButtonBeranda.ForeColor = System.Drawing.Color.White;
            this.gunaButtonBeranda.Image = global::ProjekAkhir.Properties.Resources.simple;
            this.gunaButtonBeranda.ImageSize = new System.Drawing.Size(35, 35);
            this.gunaButtonBeranda.Location = new System.Drawing.Point(0, 98);
            this.gunaButtonBeranda.Name = "gunaButtonBeranda";
            this.gunaButtonBeranda.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(130)))), ((int)(((byte)(246)))));
            this.gunaButtonBeranda.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButtonBeranda.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButtonBeranda.OnHoverImage = null;
            this.gunaButtonBeranda.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButtonBeranda.Size = new System.Drawing.Size(281, 59);
            this.gunaButtonBeranda.TabIndex = 0;
            this.gunaButtonBeranda.Text = "Beranda";
            this.gunaButtonBeranda.TextOffsetX = 18;
            this.gunaButtonBeranda.Click += new System.EventHandler(this.gunaButtonBeranda_Click);
            // 
            // gunaPanelContainer
            // 
            this.gunaPanelContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gunaPanelContainer.Location = new System.Drawing.Point(281, 88);
            this.gunaPanelContainer.Name = "gunaPanelContainer";
            this.gunaPanelContainer.Size = new System.Drawing.Size(1159, 896);
            this.gunaPanelContainer.TabIndex = 12;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1440, 984);
            this.Controls.Add(this.gunaPanelContainer);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.gunaPanel1);
            this.Name = "Menu";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Menu_Load);
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaTransfarantPictureBox3)).EndInit();
            this.gunaPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaTransfarantPictureBox gunaTransfarantPictureBox3;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaButton gunaButtonBeranda;
        private Guna.UI.WinForms.GunaPanel gunaPanelContainer;
        private Guna.UI.WinForms.GunaButton gunaButtonBudget;
        private Guna.UI.WinForms.GunaButton gunaButtonTransaksi;
    }
}