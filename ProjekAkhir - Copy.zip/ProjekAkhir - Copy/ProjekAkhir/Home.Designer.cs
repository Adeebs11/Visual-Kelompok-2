﻿namespace ProjekAkhir
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaButtonMulai = new Guna.UI.WinForms.GunaButton();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaButtonMin = new Guna.UI.WinForms.GunaButton();
            this.gunaButtonMax = new Guna.UI.WinForms.GunaButton();
            this.gunaBtnClose = new Guna.UI.WinForms.GunaButton();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Calibri", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.ForeColor = System.Drawing.Color.White;
            this.gunaLabel1.Location = new System.Drawing.Point(102, 200);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(428, 146);
            this.gunaLabel1.TabIndex = 6;
            this.gunaLabel1.Text = "SakuKu";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(134, 395);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(474, 112);
            this.gunaLabel2.TabIndex = 7;
            this.gunaLabel2.Text = "Atur aktivitas keuanganmu dengan SakuKu,\r\naplikasi keungan untuk kelola rencana f" +
    "inansial\r\ndengan mudah, capai tujuan target tabunganmu, \r\ndan pantau pengeluaran" +
    "mu\r\n";
            // 
            // gunaButtonMulai
            // 
            this.gunaButtonMulai.AnimationHoverSpeed = 0.07F;
            this.gunaButtonMulai.AnimationSpeed = 0.03F;
            this.gunaButtonMulai.BackColor = System.Drawing.Color.Transparent;
            this.gunaButtonMulai.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(94)))), ((int)(((byte)(141)))));
            this.gunaButtonMulai.BorderColor = System.Drawing.Color.Black;
            this.gunaButtonMulai.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButtonMulai.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButtonMulai.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButtonMulai.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaButtonMulai.ForeColor = System.Drawing.Color.White;
            this.gunaButtonMulai.Image = null;
            this.gunaButtonMulai.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButtonMulai.Location = new System.Drawing.Point(139, 580);
            this.gunaButtonMulai.Name = "gunaButtonMulai";
            this.gunaButtonMulai.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(130)))), ((int)(((byte)(246)))));
            this.gunaButtonMulai.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButtonMulai.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButtonMulai.OnHoverImage = null;
            this.gunaButtonMulai.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButtonMulai.OnPressedDepth = 15;
            this.gunaButtonMulai.Radius = 15;
            this.gunaButtonMulai.Size = new System.Drawing.Size(182, 42);
            this.gunaButtonMulai.TabIndex = 8;
            this.gunaButtonMulai.Text = "MULAI";
            this.gunaButtonMulai.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButtonMulai.Click += new System.EventHandler(this.gunaButtonMulai_Click);
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::ProjekAkhir.Properties.Resources.Frame;
            this.gunaPictureBox1.Location = new System.Drawing.Point(756, 292);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(562, 396);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox1.TabIndex = 9;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaButtonMin
            // 
            this.gunaButtonMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaButtonMin.AnimationHoverSpeed = 0.07F;
            this.gunaButtonMin.AnimationSpeed = 0.03F;
            this.gunaButtonMin.BackColor = System.Drawing.Color.Transparent;
            this.gunaButtonMin.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(175)))), ((int)(((byte)(216)))));
            this.gunaButtonMin.BorderColor = System.Drawing.Color.Black;
            this.gunaButtonMin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButtonMin.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButtonMin.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButtonMin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButtonMin.ForeColor = System.Drawing.Color.White;
            this.gunaButtonMin.Image = ((System.Drawing.Image)(resources.GetObject("gunaButtonMin.Image")));
            this.gunaButtonMin.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButtonMin.ImageSize = new System.Drawing.Size(24, 25);
            this.gunaButtonMin.Location = new System.Drawing.Point(1308, 12);
            this.gunaButtonMin.Name = "gunaButtonMin";
            this.gunaButtonMin.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(140)))), ((int)(((byte)(190)))));
            this.gunaButtonMin.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButtonMin.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButtonMin.OnHoverImage = null;
            this.gunaButtonMin.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButtonMin.Radius = 5;
            this.gunaButtonMin.Size = new System.Drawing.Size(36, 35);
            this.gunaButtonMin.TabIndex = 5;
            this.gunaButtonMin.Click += new System.EventHandler(this.gunaButtonMin_Click);
            // 
            // gunaButtonMax
            // 
            this.gunaButtonMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaButtonMax.AnimationHoverSpeed = 0.07F;
            this.gunaButtonMax.AnimationSpeed = 0.03F;
            this.gunaButtonMax.BackColor = System.Drawing.Color.Transparent;
            this.gunaButtonMax.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(175)))), ((int)(((byte)(216)))));
            this.gunaButtonMax.BorderColor = System.Drawing.Color.Black;
            this.gunaButtonMax.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaButtonMax.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButtonMax.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButtonMax.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButtonMax.ForeColor = System.Drawing.Color.White;
            this.gunaButtonMax.Image = ((System.Drawing.Image)(resources.GetObject("gunaButtonMax.Image")));
            this.gunaButtonMax.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButtonMax.ImageSize = new System.Drawing.Size(24, 25);
            this.gunaButtonMax.Location = new System.Drawing.Point(1350, 12);
            this.gunaButtonMax.Name = "gunaButtonMax";
            this.gunaButtonMax.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(140)))), ((int)(((byte)(190)))));
            this.gunaButtonMax.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButtonMax.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButtonMax.OnHoverImage = null;
            this.gunaButtonMax.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButtonMax.Radius = 5;
            this.gunaButtonMax.Size = new System.Drawing.Size(36, 35);
            this.gunaButtonMax.TabIndex = 4;
            this.gunaButtonMax.Click += new System.EventHandler(this.gunaButtonMax_Click);
            // 
            // gunaBtnClose
            // 
            this.gunaBtnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaBtnClose.AnimationHoverSpeed = 0.07F;
            this.gunaBtnClose.AnimationSpeed = 0.03F;
            this.gunaBtnClose.BackColor = System.Drawing.Color.Transparent;
            this.gunaBtnClose.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(175)))), ((int)(((byte)(216)))));
            this.gunaBtnClose.BorderColor = System.Drawing.Color.Black;
            this.gunaBtnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaBtnClose.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaBtnClose.FocusedColor = System.Drawing.Color.Empty;
            this.gunaBtnClose.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaBtnClose.ForeColor = System.Drawing.Color.White;
            this.gunaBtnClose.Image = ((System.Drawing.Image)(resources.GetObject("gunaBtnClose.Image")));
            this.gunaBtnClose.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaBtnClose.ImageSize = new System.Drawing.Size(24, 25);
            this.gunaBtnClose.Location = new System.Drawing.Point(1392, 12);
            this.gunaBtnClose.Name = "gunaBtnClose";
            this.gunaBtnClose.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(140)))), ((int)(((byte)(190)))));
            this.gunaBtnClose.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaBtnClose.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaBtnClose.OnHoverImage = null;
            this.gunaBtnClose.OnPressedColor = System.Drawing.Color.Black;
            this.gunaBtnClose.Radius = 5;
            this.gunaBtnClose.Size = new System.Drawing.Size(36, 35);
            this.gunaBtnClose.TabIndex = 3;
            this.gunaBtnClose.Click += new System.EventHandler(this.gunaBtnClose_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(175)))), ((int)(((byte)(216)))));
            this.ClientSize = new System.Drawing.Size(1440, 984);
            this.Controls.Add(this.gunaPictureBox1);
            this.Controls.Add(this.gunaButtonMulai);
            this.Controls.Add(this.gunaLabel2);
            this.Controls.Add(this.gunaLabel1);
            this.Controls.Add(this.gunaButtonMin);
            this.Controls.Add(this.gunaButtonMax);
            this.Controls.Add(this.gunaBtnClose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI.WinForms.GunaButton gunaBtnClose;
        private Guna.UI.WinForms.GunaButton gunaButtonMax;
        private Guna.UI.WinForms.GunaButton gunaButtonMin;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaButton gunaButtonMulai;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
    }
}